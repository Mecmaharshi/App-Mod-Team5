export const check_avalability = "https://appmodteam5.azurewebsites.net/api/Check_avalability?"

export const book_room = 'https://appmodteam5.azurewebsites.net/api/API?'