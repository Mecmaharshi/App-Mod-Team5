import "./list.css";
import Navbar from "../../components/navbar/Navbar";
import Header from "../../components/header/Header";
import { useLocation } from "react-router-dom";
import { useState } from "react";
import { format } from "date-fns";
import { DateRange } from "react-date-range";
import SearchItem from "../../components/searchItem/SearchItem";
import { check_avalability } from "../../utils/config";
import axios from "axios";
const List = () => {
  const [DELUXE_PRIME  , setDELUXE_PRIME] = useState()
const [DELUXE_SUPREME  , setDELUXE_SUPREME] = useState()
const [EXECUTIVE_CLUB_SUITE,setEXECUTIVE_CLUB_SUITE] = useState()
const [IMPERIAL_CLUB_ROOM  , setIMPERIAL_CLUB_ROOM] = useState()
const [REGAl_CLUB_SUITE  , setREGAl_CLUB_SUITE] = useState()
const [TERRACE_CLUB_SUITE  , setTERRACE_CLUB_SUITE] = useState()
let data = axios.get(check_avalability)
data.then(res=>{
    setDELUXE_PRIME(res.data.DELUXE_PRIME)
    setDELUXE_SUPREME(res.data.DELUXE_SUPREME)
    setEXECUTIVE_CLUB_SUITE(res.data.EXECUTIVE_CLUB_SUITE)
    setIMPERIAL_CLUB_ROOM(res.data.IMPERIAL_CLUB_ROOM)
    setREGAl_CLUB_SUITE(res.data.REGAl_CLUB_SUITE)
    setTERRACE_CLUB_SUITE(res.data.TERRACE_CLUB_SUITE)
})
console.log("TERRACE_CLUB_SUITE", TERRACE_CLUB_SUITE)

  const location = useLocation();
  const [destination, setDestination] = useState(location.state.destination);
  const [date, setDate] = useState(location.state.date);
  const [openDate, setOpenDate] = useState(false);
  const [options, setOptions] = useState(location.state.options);

  return (
    <div>
      <Navbar />
      <Header type="list" />
      <div className="listContainer">
        <div className="listWrapper">
          <div className="listSearch">
            <h1 className="lsTitle">Search</h1>
            <div className="lsItem">
              <label>Destination</label>
              <input placeholder={destination} type="text" />
            </div>
            <div className="lsItem">
              <label>Check-in Date</label>
              <span onClick={() => setOpenDate(!openDate)}>{`${format(
                date[0].startDate,
                "MM/dd/yyyy"
              )} to ${format(date[0].endDate, "MM/dd/yyyy")}`}</span>
              {openDate && (
                <DateRange
                  onChange={(item) => setDate([item.selection])}
                  minDate={new Date()}
                  ranges={date}
                />
              )}
            </div>
            <div className="lsItem">
              <label>Options</label>
              <div className="lsOptions">
                <div className="lsOptionItem">
                  <span className="lsOptionText">
                    Min price <small>per night</small>
                  </span>
                  <input type="number" className="lsOptionInput" />
                </div>
                <div className="lsOptionItem">
                  <span className="lsOptionText">
                    Max price <small>per night</small>
                  </span>
                  <input type="number" className="lsOptionInput" />
                </div>
                <div className="lsOptionItem">
                  <span className="lsOptionText">Adult</span>
                  <input
                    type="number"
                    min={1}
                    className="lsOptionInput"
                    placeholder={options.adult}
                  />
                </div>
                <div className="lsOptionItem">
                  <span className="lsOptionText">Children</span>
                  <input
                    type="number"
                    min={0}
                    className="lsOptionInput"
                    placeholder={options.children}
                  />
                </div>
                <div className="lsOptionItem">
                  <span className="lsOptionText">Room</span>
                  <input
                    type="number"
                    min={1}
                    className="lsOptionInput"
                    placeholder={options.room}
                  />
                </div>
              </div>
            </div>
            <button>Search</button>
          </div>
          <div className="listResult">
          <SearchItem available={DELUXE_PRIME}/>
            <SearchItem available={DELUXE_SUPREME}/>
            <SearchItem available={EXECUTIVE_CLUB_SUITE}/>
            <SearchItem available={IMPERIAL_CLUB_ROOM}/>
            <SearchItem available={REGAl_CLUB_SUITE}/>
            <SearchItem available={TERRACE_CLUB_SUITE}/>
          </div>
        </div>
      </div>
    </div>
  );
};

export default List;
